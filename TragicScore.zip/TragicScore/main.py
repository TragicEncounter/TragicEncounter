import random
import pygame
import os
from termcolor import colored

class player:
    hearts = 3
    score = 0
    row = 0
    column = 0
    highest_score = 0
    highest_score_ever = 0


class stage:
    name = 1
    rows = 8
    columns = 5
    required_score = 7

class monster:
    row = 0
    column = 0
    rotation = 0
    time = 0

def create_map(number_of_rows,number_of_columns):
    map = []
    for i in range(number_of_rows):
        row = []
        for j in range(number_of_columns):
            row.append("[ ]")
        map.append(row)
    return map


def new_stage(stage,player):
    next_stage.play()
    stage.name += 1
    stage.rows += 2
    stage.columns += 1
    if stage.name == 4:
        stage.required_score = 70
    else: stage.required_score += stage.required_score + 3
    player.hearts += 2

def the_end(player,stage,monster):
    print("\n                                                                                                         Thanks for playing :)\n" + "                                                                                                         Your score is " + str(player.score))
    update_highest_score(player)
    save_data(player)
    player.hearts = 3
    player.score = 0
    player.row = 0
    player.column = 0
    stage.name = 1
    stage.rows = 8
    stage.columns = 5
    stage.required_score = 7
    monster.row = 0
    monster.column = 0
    monster.rotation = 0
    monster.time = 0
    soundtrack.stop()


def refresh_map(map_rn,stage):
    for row in range(len(map_rn)):
        for column in range(len(map_rn[0])):
            if map_rn[row][column] == "[ ]":
                map_rn[row][column] = "[ ]"
            if map_rn[row][column] == "[P]":
                map_rn[row][column] = "[ ]"
            if map_rn[row][column] == "[S]":
                map_rn[row][column] = "[S]"
            if map_rn[row][column] == "[B]":
                map_rn[row][column] = "[B]"
            if map_rn[row][column] == "[M]":
                map_rn[row][column] = "[ ]"
            spawn_player(player,map_rn)
            if stage.name == 4:
                spawn_monster(monster,map_rn)



def check_if_full(map_rn):
    for row in range(len(map_rn)):
        for column in range(len(map_rn[0])):
            if map_rn[row][column] == "[ ]":
                return False
    return True

def print_map(map_rn):
    print("                                                                                                         Score: " + str(player.score) + " Hearts: "+ str(player.hearts))
    for row in map_rn:
        print("                                                                                                         ",end="")
        for element in row:
            if element == "[ ]":
                print(colored("[ ]","green"),end="")
                print(" ",end="")
            if element == "[P]":
                print("[P]",end="")
                print(" ", end="")
            if element == "[B]":
                print(colored("[B]","magenta"),end="")
                print(" ", end="")
            if element == "[S]":
                print(colored("[S]","yellow"),end="")
                print(" ", end="")
            if element == "[M]":
                print(colored("[M]","red"),end="")
                print(" ", end="")
        print("\n")




def spawn_entities(map_rn):
    spawn_bomb(map_rn)
    spawn_star(map_rn)

def spawn_bomb(map_rn):
    check = ""
    while check != 0:
        row = random.choice(count_rows(map_rn))
        column = random.choice(count_columns(map_rn))
        if map_rn[row][column] == "[ ]":
            map_rn[row][column] = "[B]"
            check = 0

def spawn_star(map_rn):
    check = ""
    while check != 0:
        row = random.choice(count_rows(map_rn))
        column = random.choice(count_columns(map_rn))
        if map_rn[row][column] == "[ ]":
            map_rn[row][column] = "[S]"
        check = 0


def count_rows(map_rn):
    rows = []
    n = 0
    for i in range(len(map_rn)):
        rows.append(0 + n)
        n += 1
    return rows

def count_columns(map_rn):
    columns = []
    n = 0
    for i in range(len(map_rn[0])):
        columns.append(0 + n)
        n += 1
    return columns

def update_highest_score(player):
    if player.score > player.highest_score:
        player.highest_score = player.score

def spawn_player(player,map_rn):
    for row in range(len(map_rn)):
        for column in range(len(map_rn[0])):
            if row == player.row:
                if column == player.column:
                    map_rn[row][column] = "[P]"

def spawn_monster(monster,map_rn):
    for row in range(len(map_rn)):
        for column in range(len(map_rn[0])):
            if row == monster.row and column == monster.column:
                map_rn[row][column] = "[M]"

pygame.mixer.init()
scored_sound = pygame.mixer.Sound(os.path.join('sounds','scored.wav'))
boom_sound = pygame.mixer.Sound(os.path.join('sounds','boom.wav'))
soundtrack = pygame.mixer.Sound(os.path.join('sounds','ost.wav'))
next_stage = pygame.mixer.Sound(os.path.join('sounds','new_stage.wav'))
monster_eating = pygame.mixer.Sound(os.path.join('sounds','monster_eating.wav'))
main_menu = pygame.mixer.Sound(os.path.join('sounds','main_menu.wav'))

def consequences(map_rn,player):
    if map_rn[player.row][player.column] == "[S]":
        player.score += 1
        scored_sound.play()
        print("                                                                                                         You scored!")
    if map_rn[player.row][player.column] == "[B]":
        boom_sound.play()
        player.hearts -= 1
        print("                                                                                                         You've lost a heart due to a bomb!")
    if map_rn[player.row][player.column] == "[M]":
        player.hearts = 0
        monster_eating.play()
        print("                                                                                                         The monster ate you!")

def save_data(player):
    with open("data.txt","r") as file:
        for line in file:
            biggest_score = int(line)
    player.highest_score_ever = biggest_score
    with open("data.txt","w") as file:
        if player.highest_score > biggest_score:
            file.writelines(str(player.highest_score))
        else:
            file.writelines(str(biggest_score))



def write_highest_score(name):
    with open(name,"r") as file:
        for object in file:
            print("                                                                                                         The highest score ever is " + str(object))

def monster_movement(monster,player):
    if monster.time == 0:
        if monster.rotation == 0:
            if monster.row != player.row:
                if monster.row > player.row:
                    monster.row -= 1
                else:
                    monster.row += 1
            else:
                if monster.column != player.column:
                    if monster.column > player.column:
                        monster.column -= 1
                    else:
                        monster.column += 1
        if monster.rotation == 1:
            if monster.column != player.column:
                if monster.column > player.column:
                    monster.column -= 1
                else:
                    monster.column += 1
            else:
                if monster.row != player.row:
                    if monster.row > player.row:
                        monster.row -= 1
                    else:
                        monster.row += 1
        if monster.column == player.column and monster.row == player.row:
            player.hearts = 0
        if monster.rotation == 0:
            monster.rotation = 1
        else:
            monster.rotation = 0
        monster.time = 1
    else: monster.time = 0


def main(stage,player):
        os.system('color')
        save_data(player)
        print(colored('                                                                                                         Welcome to the Tragic Score!','green'))
        while True:
            main_menu.play(-1)
            print("                                                                                                         Highest score ever is " + str(player.highest_score_ever))
            print("                                                                                                         Your highest score is: " + str(player.highest_score) + " \n                                                                                                         Good job :)")
            start = input("                                                                                                         Press 's' to start the game.")
            main_menu.stop()
            soundtrack.play(-1)
            save_data(player)
            while start == "s":
                stage_now = stage.name
                if stage.name != 4:
                    print("                                                                                                         Welcome to the level " + str(stage.name) + ".\n                                                                                                         To the next level you need " + str(
                        stage.required_score) + " points.")
                else:
                    print("                                                                                                         Welcome to the level " + str(stage.name) + ".\n                                                                                                         To complete the game you need " + str(
                        stage.required_score) + " points.")

                map_rn = create_map(stage.rows, stage.columns)
                while stage_now == stage.name:
                    if check_if_full(map_rn):
                        print("                                                                                                         The map is too full!")
                        stage_now = 0
                        start = 0
                        the_end(player, stage, monster)
                        break
                    refresh_map(map_rn, stage)
                    if stage.name == 4:
                        if monster.column == player.column and monster.row == player.row:
                            print("                                                                                                         The monster ate you!")
                            monster_eating.play()
                            player.hearts = 0
                    print_map(map_rn)
                    way = input()
                    if way == "w":
                        player.row -= 1
                    if way == "s":
                        player.row += 1
                    if way == "a":
                        player.column -= 1
                    if way == "d":
                        player.column += 1
                    if way == "quit":
                        start = 0
                        the_end(player,stage, monster)
                    consequences(map_rn, player)
                    if player.hearts == 0:
                        print("                                                                                                         Hearts: " + str(player.hearts))
                        print("                                                                                                         You died!")
                        start = 0
                        the_end(player, stage, monster)
                    if player.score == stage.required_score:
                        print("                                                                                                         You have completed stage " + str(stage.name) + ".")
                        new_stage(stage, player)
                        if stage.name == 5:
                            print("                                                                                                         Congratulations! You have completed all the levels")
                            start = 0
                            the_end(player,stage, monster)
                    if stage.name == 4:
                        monster_movement(monster, player)
                    spawn_entities(map_rn)


if __name__ == "__main__":
    main(stage,player)

